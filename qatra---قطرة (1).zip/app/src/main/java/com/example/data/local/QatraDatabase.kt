package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [WaterIntakeEntity::class, ReminderScheduleEntity::class],
    version = 1,
    exportSchema = false
)
abstract class QatraDatabase : RoomDatabase() {
    abstract fun waterDao(): WaterDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile
        private var INSTANCE: QatraDatabase? = null

        fun getInstance(context: Context): QatraDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    QatraDatabase::class.java,
                    "qatra_hydration.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
