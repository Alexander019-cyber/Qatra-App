package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {

    @Query("SELECT * FROM reminder_schedules ORDER BY hour ASC, minute ASC")
    fun observeAllReminders(): Flow<List<ReminderScheduleEntity>>

    @Query("SELECT * FROM reminder_schedules ORDER BY hour ASC, minute ASC")
    suspend fun getAllRemindersOnce(): List<ReminderScheduleEntity>

    @Query("SELECT * FROM reminder_schedules WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: Int): ReminderScheduleEntity?

    @Query("SELECT COUNT(*) FROM reminder_schedules")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderScheduleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reminders: List<ReminderScheduleEntity>)

    @Update
    suspend fun updateReminder(reminder: ReminderScheduleEntity)

    @Query("DELETE FROM reminder_schedules WHERE id = :id")
    suspend fun deleteReminderById(id: Int)
}
