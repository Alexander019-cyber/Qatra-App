package com.example.data.repository

import com.example.data.local.DailyWaterTotal
import com.example.data.local.ReminderDao
import com.example.data.local.ReminderScheduleEntity
import com.example.data.local.WaterDao
import com.example.data.local.WaterIntakeEntity
import com.example.data.preferences.HydrationPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.notifications.ReminderScheduler
import com.example.util.ArabicFormatters
import kotlinx.coroutines.flow.Flow

class HydrationRepository(
    private val waterDao: WaterDao,
    private val reminderDao: ReminderDao,
    private val preferencesRepository: UserPreferencesRepository,
    private val reminderScheduler: ReminderScheduler
) {

    val preferencesFlow: Flow<HydrationPreferences> = preferencesRepository.preferencesFlow

    val allRemindersFlow: Flow<List<ReminderScheduleEntity>> = reminderDao.observeAllReminders()

    fun observeLogsForDate(dateKey: String): Flow<List<WaterIntakeEntity>> =
        waterDao.observeLogsForDate(dateKey)

    fun observeDailyTotalsSince(startDateKey: String): Flow<List<DailyWaterTotal>> =
        waterDao.observeDailyTotalsSince(startDateKey)

    suspend fun ensureDefaultRemindersSeededAndScheduled() {
        if (reminderDao.getCount() == 0) {
            val defaults = listOf(
                ReminderScheduleEntity(hour = 9, minute = 0, isEnabled = true, label = "الصباح"),
                ReminderScheduleEntity(hour = 12, minute = 0, isEnabled = true, label = "الظهيرة"),
                ReminderScheduleEntity(hour = 15, minute = 0, isEnabled = true, label = "العصر"),
                ReminderScheduleEntity(hour = 18, minute = 0, isEnabled = true, label = "المساء"),
                ReminderScheduleEntity(hour = 21, minute = 0, isEnabled = true, label = "قبل النوم")
            )
            reminderDao.insertAll(defaults)
        }
        rescheduleReminders()
    }

    suspend fun logWater(amountMl: Int) {
        val log = WaterIntakeEntity(
            amountMl = amountMl,
            timestampMillis = System.currentTimeMillis(),
            dateKey = ArabicFormatters.todayDateKey()
        )
        waterDao.insertLog(log)
    }

    suspend fun logDefaultCup(): Int {
        val prefs = preferencesRepository.getPreferencesOnce()
        logWater(prefs.cupSizeMl)
        return prefs.cupSizeMl
    }

    suspend fun undoLatestForToday() {
        waterDao.deleteLatestLogForDate(ArabicFormatters.todayDateKey())
    }

    suspend fun deleteLogById(id: Long) {
        waterDao.deleteLogById(id)
    }

    suspend fun setCupSizeMl(cupSizeMl: Int) {
        preferencesRepository.setCupSizeMl(cupSizeMl)
    }

    suspend fun setDailyGoalMl(goalMl: Int) {
        preferencesRepository.setDailyGoalMl(goalMl)
    }

    suspend fun setRemindersGloballyEnabled(enabled: Boolean) {
        preferencesRepository.setRemindersGloballyEnabled(enabled)
        rescheduleReminders()
    }

    suspend fun addReminder(hour: Int, minute: Int, label: String) {
        val cleanLabel = label.trim().ifEmpty { "تذكير شرب الماء" }
        val newId = reminderDao.insertReminder(
            ReminderScheduleEntity(
                hour = hour,
                minute = minute,
                isEnabled = true,
                label = cleanLabel
            )
        ).toInt()
        val inserted = reminderDao.getReminderById(newId)
        val prefs = preferencesRepository.getPreferencesOnce()
        if (inserted != null && prefs.remindersGloballyEnabled) {
            reminderScheduler.scheduleReminder(inserted)
        }
    }

    suspend fun updateReminder(reminder: ReminderScheduleEntity) {
        reminderDao.updateReminder(reminder)
        val prefs = preferencesRepository.getPreferencesOnce()
        if (prefs.remindersGloballyEnabled && reminder.isEnabled) {
            reminderScheduler.scheduleReminder(reminder)
        } else {
            reminderScheduler.cancelReminder(reminder.id)
        }
    }

    suspend fun deleteReminder(id: Int) {
        reminderScheduler.cancelReminder(id)
        reminderDao.deleteReminderById(id)
    }

    suspend fun rescheduleReminders() {
        val prefs = preferencesRepository.getPreferencesOnce()
        val reminders = reminderDao.getAllRemindersOnce()
        reminderScheduler.syncAllReminders(reminders, prefs.remindersGloballyEnabled)
    }
}
