package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.qatraDataStore: DataStore<Preferences> by preferencesDataStore(name = "qatra_settings")

data class HydrationPreferences(
    val dailyGoalMl: Int = DEFAULT_DAILY_GOAL_ML,
    val cupSizeMl: Int = DEFAULT_CUP_SIZE_ML,
    val remindersGloballyEnabled: Boolean = true
) {
    companion object {
        const val DEFAULT_DAILY_GOAL_ML = 2000
        const val DEFAULT_CUP_SIZE_ML = 250
    }
}

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val DAILY_GOAL_ML = intPreferencesKey("daily_goal_ml")
        val CUP_SIZE_ML = intPreferencesKey("cup_size_ml")
        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_globally_enabled")
    }

    val preferencesFlow: Flow<HydrationPreferences> = context.qatraDataStore.data.map { prefs ->
        HydrationPreferences(
            dailyGoalMl = (prefs[Keys.DAILY_GOAL_ML] ?: HydrationPreferences.DEFAULT_DAILY_GOAL_ML)
                .coerceIn(500, 5000),
            cupSizeMl = (prefs[Keys.CUP_SIZE_ML] ?: HydrationPreferences.DEFAULT_CUP_SIZE_ML)
                .coerceIn(50, 1000),
            remindersGloballyEnabled = prefs[Keys.REMINDERS_ENABLED] ?: true
        )
    }

    suspend fun getPreferencesOnce(): HydrationPreferences = preferencesFlow.first()

    suspend fun setDailyGoalMl(goalMl: Int) {
        val clamped = goalMl.coerceIn(500, 5000)
        context.qatraDataStore.edit { prefs ->
            prefs[Keys.DAILY_GOAL_ML] = clamped
        }
    }

    suspend fun setCupSizeMl(cupMl: Int) {
        val clamped = cupMl.coerceIn(50, 1000)
        context.qatraDataStore.edit { prefs ->
            prefs[Keys.CUP_SIZE_ML] = clamped
        }
    }

    suspend fun setRemindersGloballyEnabled(enabled: Boolean) {
        context.qatraDataStore.edit { prefs ->
            prefs[Keys.REMINDERS_ENABLED] = enabled
        }
    }
}
