package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class DailyWaterTotal(
    val dateKey: String,
    val totalMl: Int,
    val cupsCount: Int
)

@Dao
interface WaterDao {

    @Query("SELECT * FROM water_intakes WHERE dateKey = :dateKey ORDER BY timestampMillis DESC")
    fun observeLogsForDate(dateKey: String): Flow<List<WaterIntakeEntity>>

    @Query(
        """
        SELECT dateKey, SUM(amountMl) AS totalMl, COUNT(*) AS cupsCount
        FROM water_intakes
        WHERE dateKey >= :startDateKey
        GROUP BY dateKey
        ORDER BY dateKey ASC
        """
    )
    fun observeDailyTotalsSince(startDateKey: String): Flow<List<DailyWaterTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: WaterIntakeEntity): Long

    @Query("DELETE FROM water_intakes WHERE id = :id")
    suspend fun deleteLogById(id: Long)

    @Query(
        """
        DELETE FROM water_intakes
        WHERE id = (
            SELECT id FROM water_intakes
            WHERE dateKey = :dateKey
            ORDER BY timestampMillis DESC
            LIMIT 1
        )
        """
    )
    suspend fun deleteLatestLogForDate(dateKey: String)
}
