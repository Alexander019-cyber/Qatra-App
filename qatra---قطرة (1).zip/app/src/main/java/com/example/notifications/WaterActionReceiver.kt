package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.QatraApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WaterActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_LOG_CUP) return
        val notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, -1)

        val pendingResult = goAsync()
        val app = context.applicationContext as QatraApplication

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                app.hydrationRepository.logDefaultCup()
                if (notificationId != -1) {
                    NotificationHelper.cancelNotification(context, notificationId)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_LOG_CUP = "com.aistudio.qatra.ACTION_LOG_CUP"
        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    }
}
