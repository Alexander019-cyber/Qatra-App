package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.QatraApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ReminderScheduler.ACTION_TRIGGER_REMINDER) return
        val reminderId = intent.getIntExtra(ReminderScheduler.EXTRA_REMINDER_ID, -1)
        if (reminderId == -1) return

        val pendingResult = goAsync()
        val app = context.applicationContext as QatraApplication

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefs = app.preferencesRepository.getPreferencesOnce()
                val reminder = app.database.reminderDao().getReminderById(reminderId)
                if (prefs.remindersGloballyEnabled && reminder != null && reminder.isEnabled) {
                    NotificationHelper.showHydrationReminder(
                        context = context,
                        notificationId = 2000 + reminder.id,
                        reminderLabel = reminder.label
                    )
                    app.reminderScheduler.scheduleReminder(reminder, forceNextDay = true)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
