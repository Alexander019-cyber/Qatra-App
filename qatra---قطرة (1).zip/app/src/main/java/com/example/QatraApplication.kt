package com.example

import android.app.Application
import com.example.data.local.QatraDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.HydrationRepository
import com.example.notifications.NotificationHelper
import com.example.notifications.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class QatraApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: QatraDatabase by lazy {
        QatraDatabase.getInstance(this)
    }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(this)
    }

    val reminderScheduler: ReminderScheduler by lazy {
        ReminderScheduler(this)
    }

    val hydrationRepository: HydrationRepository by lazy {
        HydrationRepository(
            waterDao = database.waterDao(),
            reminderDao = database.reminderDao(),
            preferencesRepository = preferencesRepository,
            reminderScheduler = reminderScheduler
        )
    }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
        appScope.launch {
            hydrationRepository.ensureDefaultRemindersSeededAndScheduled()
        }
    }
}
