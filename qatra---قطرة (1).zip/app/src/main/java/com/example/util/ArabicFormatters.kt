package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ArabicFormatters {

    private val arabicLocale = Locale("ar")

    fun todayDateKey(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return formatter.format(Date())
    }

    fun dateKeyDaysAgo(daysAgo: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    fun lastNDaysKeys(days: Int): List<String> {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return (days - 1 downTo 0).map { daysAgo ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
            formatter.format(cal.time)
        }
    }

    fun formatFullArabicDate(date: Date = Date()): String {
        val formatter = SimpleDateFormat("EEEE، d MMMM yyyy", arabicLocale)
        return toWesternDigits(formatter.format(date))
    }

    fun formatTime12hArabic(hour: Int, minute: Int): String {
        val period = if (hour < 12) "صباحاً" else "مساءً"
        val hour12 = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format(Locale.US, "%02d:%02d %s", hour12, minute, period)
    }

    fun formatTimestampTime(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return formatTime12hArabic(
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE)
        )
    }

    fun formatDayLabel(dateKey: String): String {
        val today = todayDateKey()
        val yesterday = dateKeyDaysAgo(1)
        return when (dateKey) {
            today -> "اليوم"
            yesterday -> "أمس"
            else -> {
                val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateKey)
                if (parsed != null) {
                    val cal = Calendar.getInstance().apply { time = parsed }
                    when (cal.get(Calendar.DAY_OF_WEEK)) {
                        Calendar.SATURDAY -> "السبت"
                        Calendar.SUNDAY -> "الأحد"
                        Calendar.MONDAY -> "الإثنين"
                        Calendar.TUESDAY -> "الثلاثاء"
                        Calendar.WEDNESDAY -> "الأربعاء"
                        Calendar.THURSDAY -> "الخميس"
                        Calendar.FRIDAY -> "الجمعة"
                        else -> dateKey
                    }
                } else {
                    dateKey
                }
            }
        }
    }

    fun formatShortDateLabel(dateKey: String): String {
        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateKey) ?: return dateKey
        val formatted = SimpleDateFormat("d MMM", arabicLocale).format(parsed)
        return toWesternDigits(formatted)
    }

    fun formatLitersOrMl(ml: Int): String {
        return if (ml >= 1000 && ml % 100 == 0) {
            val liters = ml / 1000f
            if (ml % 1000 == 0) {
                "${ml / 1000} لتر"
            } else {
                String.format(Locale.US, "%.1f لتر", liters)
            }
        } else {
            "$ml مل"
        }
    }

    private fun toWesternDigits(input: String): String {
        val builder = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> builder.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> builder.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> builder.append(ch)
            }
        }
        return builder.toString()
    }
}
