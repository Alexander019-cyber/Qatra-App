package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.QatraApplication
import com.example.data.local.ReminderScheduleEntity
import com.example.data.local.WaterIntakeEntity
import com.example.data.preferences.HydrationPreferences
import com.example.data.repository.HydrationRepository
import com.example.notifications.NotificationHelper
import com.example.util.ArabicFormatters
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DaySummary(
    val dateKey: String,
    val dayLabel: String,
    val shortDateLabel: String,
    val totalMl: Int,
    val cupsCount: Int,
    val goalReached: Boolean
)

data class QatraUiState(
    val todayDateKey: String = ArabicFormatters.todayDateKey(),
    val todayFormattedDate: String = ArabicFormatters.formatFullArabicDate(),
    val todayLogs: List<WaterIntakeEntity> = emptyList(),
    val todayTotalMl: Int = 0,
    val todayCupsCount: Int = 0,
    val dailyGoalMl: Int = HydrationPreferences.DEFAULT_DAILY_GOAL_ML,
    val cupSizeMl: Int = HydrationPreferences.DEFAULT_CUP_SIZE_ML,
    val remindersGloballyEnabled: Boolean = true,
    val reminders: List<ReminderScheduleEntity> = emptyList(),
    val weeklyDays: List<DaySummary> = emptyList(),
    val monthlyDays: List<DaySummary> = emptyList(),
    val weeklyAverageMl: Int = 0,
    val weeklyTotalMl: Int = 0,
    val weeklyGoalReachedCount: Int = 0,
    val isLoading: Boolean = true
) {
    val progressFraction: Float
        get() = if (dailyGoalMl <= 0) 0f else (todayTotalMl.toFloat() / dailyGoalMl.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = if (dailyGoalMl <= 0) 0 else ((todayTotalMl * 100f) / dailyGoalMl).toInt().coerceAtLeast(0)

    val remainingMl: Int
        get() = (dailyGoalMl - todayTotalMl).coerceAtLeast(0)

    val isGoalReached: Boolean
        get() = todayTotalMl >= dailyGoalMl
}

@OptIn(ExperimentalCoroutinesApi::class)
class QatraViewModel(
    application: Application,
    private val repository: HydrationRepository
) : AndroidViewModel(application) {

    private val currentDateKey = MutableStateFlow(ArabicFormatters.todayDateKey())

    private val _uiMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val uiMessage: SharedFlow<String> = _uiMessage.asSharedFlow()

    private val _celebrateEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 2)
    val celebrateEvent: SharedFlow<Unit> = _celebrateEvent.asSharedFlow()

    private val todayLogsFlow = currentDateKey.flatMapLatest { dateKey ->
        repository.observeLogsForDate(dateKey)
    }

    private val thirtyDayTotalsFlow = currentDateKey.flatMapLatest {
        repository.observeDailyTotalsSince(ArabicFormatters.dateKeyDaysAgo(29))
    }

    val uiState: StateFlow<QatraUiState> = combine(
        currentDateKey,
        todayLogsFlow,
        thirtyDayTotalsFlow,
        repository.preferencesFlow,
        repository.allRemindersFlow
    ) { dateKey, todayLogs, rawTotals, prefs, reminders ->
        val totalsMap = rawTotals.associateBy { it.dateKey }

        val last7Keys = ArabicFormatters.lastNDaysKeys(7)
        val weeklyDays = last7Keys.map { key ->
            val record = totalsMap[key]
            val total = record?.totalMl ?: 0
            DaySummary(
                dateKey = key,
                dayLabel = ArabicFormatters.formatDayLabel(key),
                shortDateLabel = ArabicFormatters.formatShortDateLabel(key),
                totalMl = total,
                cupsCount = record?.cupsCount ?: 0,
                goalReached = total >= prefs.dailyGoalMl
            )
        }

        val last30Keys = ArabicFormatters.lastNDaysKeys(30).reversed()
        val monthlyDays = last30Keys.map { key ->
            val record = totalsMap[key]
            val total = record?.totalMl ?: 0
            DaySummary(
                dateKey = key,
                dayLabel = ArabicFormatters.formatDayLabel(key),
                shortDateLabel = ArabicFormatters.formatShortDateLabel(key),
                totalMl = total,
                cupsCount = record?.cupsCount ?: 0,
                goalReached = total >= prefs.dailyGoalMl
            )
        }

        val todayTotal = todayLogs.sumOf { it.amountMl }
        val weeklyTotal = weeklyDays.sumOf { it.totalMl }
        val weeklyAvg = weeklyTotal / 7
        val weeklyGoalsMet = weeklyDays.count { it.goalReached }

        QatraUiState(
            todayDateKey = dateKey,
            todayFormattedDate = ArabicFormatters.formatFullArabicDate(),
            todayLogs = todayLogs,
            todayTotalMl = todayTotal,
            todayCupsCount = todayLogs.size,
            dailyGoalMl = prefs.dailyGoalMl,
            cupSizeMl = prefs.cupSizeMl,
            remindersGloballyEnabled = prefs.remindersGloballyEnabled,
            reminders = reminders,
            weeklyDays = weeklyDays,
            monthlyDays = monthlyDays,
            weeklyAverageMl = weeklyAvg,
            weeklyTotalMl = weeklyTotal,
            weeklyGoalReachedCount = weeklyGoalsMet,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QatraUiState()
    )

    fun refreshCurrentDate() {
        val latestKey = ArabicFormatters.todayDateKey()
        if (currentDateKey.value != latestKey) {
            currentDateKey.value = latestKey
        }
    }

    fun addCup() {
        val state = uiState.value
        val previousTotal = state.todayTotalMl
        val cupSize = state.cupSizeMl
        viewModelScope.launch {
            repository.logWater(cupSize)
            if (previousTotal < state.dailyGoalMl && previousTotal + cupSize >= state.dailyGoalMl) {
                _celebrateEvent.tryEmit(Unit)
                _uiMessage.tryEmit("ما شاء الله! حققت هدفك اليومي بالكامل")
            } else {
                _uiMessage.tryEmit("تمت إضافة $cupSize مل بنجاح")
            }
        }
    }

    fun addCustomAmount(amountMl: Int) {
        val state = uiState.value
        val previousTotal = state.todayTotalMl
        viewModelScope.launch {
            repository.logWater(amountMl)
            if (previousTotal < state.dailyGoalMl && previousTotal + amountMl >= state.dailyGoalMl) {
                _celebrateEvent.tryEmit(Unit)
                _uiMessage.tryEmit("ما شاء الله! حققت هدفك اليومي بالكامل")
            } else {
                _uiMessage.tryEmit("تمت إضافة $amountMl مل بنجاح")
            }
        }
    }

    fun undoLastCup() {
        if (uiState.value.todayLogs.isEmpty()) return
        viewModelScope.launch {
            repository.undoLatestForToday()
            _uiMessage.tryEmit("تم التراجع عن آخر كوب")
        }
    }

    fun deleteLog(logId: Long) {
        viewModelScope.launch {
            repository.deleteLogById(logId)
            _uiMessage.tryEmit("تم حذف السجل")
        }
    }

    fun setCupSize(cupSizeMl: Int) {
        viewModelScope.launch {
            repository.setCupSizeMl(cupSizeMl)
            _uiMessage.tryEmit("تم تحديد حجم الكوب: $cupSizeMl مل")
        }
    }

    fun setDailyGoal(goalMl: Int) {
        viewModelScope.launch {
            repository.setDailyGoalMl(goalMl)
            _uiMessage.tryEmit("تم تحديث الهدف اليومي: $goalMl مل")
        }
    }

    fun setRemindersGloballyEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setRemindersGloballyEnabled(enabled)
            _uiMessage.tryEmit(
                if (enabled) "تم تشغيل تذكيرات شرب الماء" else "تم إيقاف جميع التذكيرات مؤقتاً"
            )
        }
    }

    fun addReminder(hour: Int, minute: Int, label: String) {
        viewModelScope.launch {
            repository.addReminder(hour, minute, label)
            _uiMessage.tryEmit("تم حفظ موعد التذكير بنجاح")
        }
    }

    fun updateReminderTime(
        reminder: ReminderScheduleEntity,
        hour: Int,
        minute: Int,
        label: String
    ) {
        viewModelScope.launch {
            repository.updateReminder(
                reminder.copy(
                    hour = hour,
                    minute = minute,
                    label = label.trim().ifEmpty { "تذكير شرب الماء" },
                    isEnabled = true
                )
            )
            _uiMessage.tryEmit("تم تحديث موعد التذكير")
        }
    }

    fun toggleReminder(reminder: ReminderScheduleEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.updateReminder(reminder.copy(isEnabled = enabled))
        }
    }

    fun deleteReminder(id: Int) {
        viewModelScope.launch {
            repository.deleteReminder(id)
            _uiMessage.tryEmit("تم حذف التذكير")
        }
    }

    fun sendTestNotification() {
        val context = getApplication<Application>()
        if (NotificationHelper.hasNotificationPermission(context)) {
            NotificationHelper.showHydrationReminder(
                context = context,
                notificationId = 9999,
                reminderLabel = "إشعار تجريبي"
            )
            _uiMessage.tryEmit("تم إرسال إشعار تجريبي الآن")
        } else {
            _uiMessage.tryEmit("يرجى السماح بالإشعارات أولاً لتجربة التنبيه")
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as QatraApplication
                QatraViewModel(
                    application = app,
                    repository = app.hydrationRepository
                )
            }
        }
    }
}
