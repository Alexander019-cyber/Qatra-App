package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CoralBlush
import com.example.ui.theme.DeepOcean
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBright
import com.example.ui.theme.SkyLight
import com.example.ui.theme.SkyMist
import com.example.ui.theme.SkyPrimary
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun CuteWaterDropMascot(
    progressFraction: Float,
    progressPercent: Int,
    todayCupsCount: Int,
    modifier: Modifier = Modifier
) {
    val clampedProgress = progressFraction.coerceIn(0f, 1f)
    val animatedFill by animateFloatAsState(
        targetValue = clampedProgress,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "drop_fill"
    )

    // Gentle bounce when cups count increases
    var bounceTrigger by remember { mutableStateOf(false) }
    LaunchedEffect(todayCupsCount) {
        if (todayCupsCount > 0) {
            bounceTrigger = true
            delay(220)
            bounceTrigger = false
        }
    }
    val mascotScale by animateFloatAsState(
        targetValue = if (bounceTrigger) 1.07f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "drop_bounce"
    )

    // Continuous smooth wave phase + gentle float
    val infiniteTransition = rememberInfiniteTransition(label = "water_waves")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val bobOffset by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bob_offset"
    )

    // Cute periodic eye blink
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3600)
            isBlinking = true
            delay(140)
            isBlinking = false
        }
    }

    val mascotDescription = stringResource(R.string.cd_mascot_drop)
    val speechBubbleText = remember(progressPercent) {
        when {
            progressPercent == 0 -> "صباح الخير! لنبدأ بأول كوب ماء اليوم"
            progressPercent < 40 -> "بداية طيبة! جسمك يشكرك على كل قطرة"
            progressPercent < 80 -> "أحسنت! قطوة وقطرة تقترب من هدفك"
            progressPercent < 100 -> "رائع جداً! بقي القليل وتكمل هدف اليوم"
            else -> "ما شاء الله! حققت هدفك اليومي بنجاح"
        }
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val containerColor = MaterialTheme.colorScheme.primaryContainer
    val borderColor = MaterialTheme.colorScheme.outline
    val textColor = MaterialTheme.colorScheme.onPrimaryContainer
    val surfaceColor = MaterialTheme.colorScheme.surface

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Friendly speech bubble from Qatura
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(surfaceColor.copy(alpha = 0.92f))
                .border(1.dp, borderColor, RoundedCornerShape(20.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text(
                text = speechBubbleText,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = textColor,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .size(210.dp)
                .graphicsLayer {
                    scaleX = mascotScale
                    scaleY = mascotScale
                    translationY = bobOffset
                }
                .semantics { contentDescription = mascotDescription },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Outer soft sky glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            SkyLight.copy(alpha = 0.24f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.5f, h * 0.58f),
                        radius = w * 0.52f
                    ),
                    center = Offset(w * 0.5f, h * 0.58f),
                    radius = w * 0.52f
                )

                // Teardrop silhouette path
                val dropPath = Path().apply {
                    moveTo(w * 0.5f, h * 0.06f)
                    cubicTo(
                        w * 0.68f, h * 0.28f,
                        w * 0.88f, h * 0.48f,
                        w * 0.88f, h * 0.66f
                    )
                    cubicTo(
                        w * 0.88f, h * 0.86f,
                        w * 0.71f, h * 0.95f,
                        w * 0.5f, h * 0.95f
                    )
                    cubicTo(
                        w * 0.29f, h * 0.95f,
                        w * 0.12f, h * 0.86f,
                        w * 0.12f, h * 0.66f
                    )
                    cubicTo(
                        w * 0.12f, h * 0.48f,
                        w * 0.32f, h * 0.28f,
                        w * 0.5f, h * 0.06f
                    )
                    close()
                }

                // Soft milky sky backdrop inside the drop
                drawPath(
                    path = dropPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            PureWhite,
                            containerColor
                        )
                    )
                )

                // Clipped animated water waves inside drop
                clipPath(dropPath) {
                    val fillTop = h * (0.95f - animatedFill * 0.84f)
                    val waveAmp = if (animatedFill in 0.02f..0.98f) h * 0.032f else h * 0.01f

                    // Back lighter wave
                    val backWave = Path().apply {
                        moveTo(0f, h)
                        lineTo(0f, fillTop)
                        var x = 0f
                        while (x <= w) {
                            val angle = (x / w) * 2.5f * PI.toFloat() + wavePhase + 1.4f
                            val y = fillTop + sin(angle) * waveAmp
                            lineTo(x, y)
                            x += 6f
                        }
                        lineTo(w, h)
                        close()
                    }
                    drawPath(
                        path = backWave,
                        color = SkyMist.copy(alpha = 0.85f)
                    )

                    // Front vibrant sky-blue wave
                    val frontWave = Path().apply {
                        moveTo(0f, h)
                        lineTo(0f, fillTop + 4f)
                        var x = 0f
                        while (x <= w) {
                            val angle = (x / w) * 2.5f * PI.toFloat() - wavePhase
                            val y = (fillTop + 4f) + sin(angle) * waveAmp
                            lineTo(x, y)
                            x += 6f
                        }
                        lineTo(w, h)
                        close()
                    }
                    drawPath(
                        path = frontWave,
                        brush = Brush.verticalGradient(
                            colors = listOf(SkyLight, SkyBright, SkyPrimary),
                            startY = fillTop,
                            endY = h
                        )
                    )
                }

                // Glossy highlight arc on upper-left
                drawArc(
                    color = PureWhite.copy(alpha = 0.72f),
                    startAngle = 210f,
                    sweepAngle = 42f,
                    useCenter = false,
                    topLeft = Offset(w * 0.21f, h * 0.36f),
                    size = Size(w * 0.36f, h * 0.44f),
                    style = Stroke(width = w * 0.028f, cap = StrokeCap.Round)
                )

                // Drop outline
                drawPath(
                    path = dropPath,
                    color = primaryColor.copy(alpha = 0.55f),
                    style = Stroke(width = w * 0.022f)
                )

                // Cute Cartoon Face (eyes, shine, cheeks, smile)
                val eyeY = h * 0.58f
                val leftEyeX = w * 0.39f
                val rightEyeX = w * 0.61f
                val eyeRadius = w * 0.044f

                if (isBlinking) {
                    val blinkStroke = Stroke(width = w * 0.018f, cap = StrokeCap.Round)
                    drawLine(
                        color = DeepOcean,
                        start = Offset(leftEyeX - eyeRadius, eyeY),
                        end = Offset(leftEyeX + eyeRadius, eyeY),
                        strokeWidth = blinkStroke.width,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = DeepOcean,
                        start = Offset(rightEyeX - eyeRadius, eyeY),
                        end = Offset(rightEyeX + eyeRadius, eyeY),
                        strokeWidth = blinkStroke.width,
                        cap = StrokeCap.Round
                    )
                } else {
                    // Eyes
                    drawCircle(color = DeepOcean, radius = eyeRadius, center = Offset(leftEyeX, eyeY))
                    drawCircle(color = DeepOcean, radius = eyeRadius, center = Offset(rightEyeX, eyeY))
                    // Eye sparkles
                    drawCircle(
                        color = PureWhite,
                        radius = eyeRadius * 0.38f,
                        center = Offset(leftEyeX - eyeRadius * 0.28f, eyeY - eyeRadius * 0.28f)
                    )
                    drawCircle(
                        color = PureWhite,
                        radius = eyeRadius * 0.38f,
                        center = Offset(rightEyeX - eyeRadius * 0.28f, eyeY - eyeRadius * 0.28f)
                    )
                }

                // Rosy cheeks
                drawCircle(
                    color = CoralBlush.copy(alpha = 0.55f),
                    radius = w * 0.042f,
                    center = Offset(w * 0.30f, h * 0.65f)
                )
                drawCircle(
                    color = CoralBlush.copy(alpha = 0.55f),
                    radius = w * 0.042f,
                    center = Offset(w * 0.70f, h * 0.65f)
                )

                // Smile (bigger open grin when >= 100%)
                if (progressPercent >= 100) {
                    drawArc(
                        color = DeepOcean,
                        startAngle = 15f,
                        sweepAngle = 150f,
                        useCenter = true,
                        topLeft = Offset(w * 0.42f, h * 0.63f),
                        size = Size(w * 0.16f, h * 0.10f)
                    )
                    // Sparkle drops around top
                    drawCircle(
                        color = SkyLight,
                        radius = w * 0.022f,
                        center = Offset(w * 0.18f, h * 0.26f)
                    )
                    drawCircle(
                        color = SkyPrimary,
                        radius = w * 0.016f,
                        center = Offset(w * 0.83f, h * 0.28f)
                    )
                } else {
                    drawArc(
                        color = DeepOcean,
                        startAngle = 20f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(w * 0.42f, h * 0.62f),
                        size = Size(w * 0.16f, h * 0.09f),
                        style = Stroke(width = w * 0.022f, cap = StrokeCap.Round)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Clear percentage pill beneath mascot
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(
                    if (progressPercent >= 100) MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.primaryContainer
                )
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "$progressPercent% من هدف اليوم",
                style = MaterialTheme.typography.titleMedium,
                color = if (progressPercent >= 100) MaterialTheme.colorScheme.onTertiaryContainer
                else MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}
