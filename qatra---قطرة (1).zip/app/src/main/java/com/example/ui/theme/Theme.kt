package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val QatraLightColorScheme = lightColorScheme(
    primary = SkyPrimary,
    onPrimary = PureWhite,
    primaryContainer = SkyContainer,
    onPrimaryContainer = DeepOcean,
    secondary = SkyBright,
    onSecondary = PureWhite,
    secondaryContainer = SkyMist,
    onSecondaryContainer = DeepOcean,
    tertiary = MintSuccess,
    onTertiary = PureWhite,
    tertiaryContainer = MintContainer,
    onTertiaryContainer = DeepOcean,
    background = SkySurfaceTop,
    onBackground = DeepOcean,
    surface = PureWhite,
    onSurface = DeepOcean,
    surfaceVariant = SkyContainer,
    onSurfaceVariant = SlateBlue,
    outline = SkyCardBorder,
    outlineVariant = SoftDivider,
    error = CoralWarm,
    onError = PureWhite
)

private val QatraDarkColorScheme = darkColorScheme(
    primary = NightSkyPrimary,
    onPrimary = NightSkyOnPrimary,
    primaryContainer = NightSkyContainer,
    onPrimaryContainer = NightSkyText,
    secondary = SkyLight,
    onSecondary = NightSkyOnPrimary,
    secondaryContainer = NightSkyContainer,
    onSecondaryContainer = NightSkyText,
    tertiary = MintSuccess,
    onTertiary = PureWhite,
    tertiaryContainer = ColorTokens.DarkMintContainer,
    onTertiaryContainer = NightSkyText,
    background = NightSkyBg,
    onBackground = NightSkyText,
    surface = NightSkySurface,
    onSurface = NightSkyText,
    surfaceVariant = NightSkyContainer,
    onSurfaceVariant = NightSkyMuted,
    outline = ColorTokens.DarkBorder,
    outlineVariant = NightSkyContainer,
    error = CoralBlush,
    onError = NightSkyOnPrimary
)

private object ColorTokens {
    val DarkMintContainer = androidx.compose.ui.graphics.Color(0xFF11423F)
    val DarkBorder = androidx.compose.ui.graphics.Color(0xFF1F4766)
}

val QatraShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun QatraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) QatraDarkColorScheme else QatraLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = QatraTypography,
        shapes = QatraShapes,
        content = content
    )
}
