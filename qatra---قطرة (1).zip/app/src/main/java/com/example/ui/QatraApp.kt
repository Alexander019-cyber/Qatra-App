package com.example.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ui.components.CupSizeDialog
import com.example.ui.components.DailyGoalDialog
import com.example.ui.components.GoalCelebrationDialog
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.RemindersScreen
import com.example.ui.screens.TodayScreen

const val ROUTE_TODAY = "today"
const val ROUTE_HISTORY = "history"
const val ROUTE_REMINDERS = "reminders"

private data class QatraNavItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun QatraApp(
    viewModel: QatraViewModel = viewModel(factory = QatraViewModel.Factory)
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val lifecycleOwner = LocalLifecycleOwner.current

    var showCupSizeDialog by remember { mutableStateOf(false) }
    var showGoalDialog by remember { mutableStateOf(false) }
    var showCelebrationDialog by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshCurrentDate()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { message ->
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(
                message = message,
                duration = SnackbarDuration.Short
            )
        }
    }

    LaunchedEffect(Unit) {
        viewModel.celebrateEvent.collect {
            showCelebrationDialog = true
        }
    }

    val navItems = remember {
        listOf(
            QatraNavItem(
                route = ROUTE_TODAY,
                labelRes = R.string.nav_today,
                selectedIcon = Icons.Filled.WaterDrop,
                unselectedIcon = Icons.Outlined.WaterDrop,
                testTag = "nav_tab_today"
            ),
            QatraNavItem(
                route = ROUTE_HISTORY,
                labelRes = R.string.nav_history,
                selectedIcon = Icons.Filled.BarChart,
                unselectedIcon = Icons.Outlined.BarChart,
                testTag = "nav_tab_history"
            ),
            QatraNavItem(
                route = ROUTE_REMINDERS,
                labelRes = R.string.nav_reminders,
                selectedIcon = Icons.Filled.NotificationsActive,
                unselectedIcon = Icons.Outlined.Notifications,
                testTag = "nav_tab_reminders"
            )
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // Enforce native Arabic RTL layout across the entire app
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp
                        ) {
                            navItems.forEach { item ->
                                val selected = currentDestination?.hierarchy?.any {
                                    it.route == item.route
                                } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(item.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = stringResource(item.labelRes)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = stringResource(item.labelRes),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            navItems.forEach { item ->
                                val selected = currentDestination?.hierarchy?.any {
                                    it.route == item.route
                                } == true
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(item.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = stringResource(item.labelRes)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = stringResource(item.labelRes),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_TODAY,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(ROUTE_TODAY) {
                            TodayScreen(
                                uiState = uiState,
                                onAddCup = viewModel::addCup,
                                onUndoLastCup = viewModel::undoLastCup,
                                onDeleteLog = viewModel::deleteLog,
                                onOpenCupSizeDialog = { showCupSizeDialog = true },
                                onOpenGoalDialog = { showGoalDialog = true }
                            )
                        }
                        composable(ROUTE_HISTORY) {
                            HistoryScreen(uiState = uiState)
                        }
                        composable(ROUTE_REMINDERS) {
                            RemindersScreen(
                                uiState = uiState,
                                onToggleGlobalReminders = viewModel::setRemindersGloballyEnabled,
                                onToggleReminder = viewModel::toggleReminder,
                                onAddReminder = viewModel::addReminder,
                                onUpdateReminder = viewModel::updateReminderTime,
                                onDeleteReminder = viewModel::deleteReminder,
                                onTestNotification = viewModel::sendTestNotification,
                                onOpenCupSizeDialog = { showCupSizeDialog = true },
                                onOpenGoalDialog = { showGoalDialog = true }
                            )
                        }
                    }
                }
            }
        }

        if (showCupSizeDialog) {
            CupSizeDialog(
                currentCupSizeMl = uiState.cupSizeMl,
                onDismiss = { showCupSizeDialog = false },
                onConfirm = { newSize ->
                    viewModel.setCupSize(newSize)
                    showCupSizeDialog = false
                }
            )
        }

        if (showGoalDialog) {
            DailyGoalDialog(
                currentGoalMl = uiState.dailyGoalMl,
                cupSizeMl = uiState.cupSizeMl,
                onDismiss = { showGoalDialog = false },
                onConfirm = { newGoal ->
                    viewModel.setDailyGoal(newGoal)
                    showGoalDialog = false
                }
            )
        }

        if (showCelebrationDialog) {
            GoalCelebrationDialog(
                dailyGoalMl = uiState.dailyGoalMl,
                onDismiss = { showCelebrationDialog = false }
            )
        }
    }
}
