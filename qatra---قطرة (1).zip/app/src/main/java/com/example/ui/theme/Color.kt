package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Sky Blue Palette
val SkyPrimary = Color(0xFF0284C7)       // Deep vibrant sky blue (high contrast with white)
val SkyBright = Color(0xFF0EA5E9)        // Bright cheerful sky blue
val SkyLight = Color(0xFF38BDF8)         // Soft glowing aqua-sky
val SkyMist = Color(0xFFBAE6FD)          // Gentle wave & highlight blue
val SkyContainer = Color(0xFFE0F2FE)     // Soft ice-blue container
val SkySurfaceTop = Color(0xFFF2F9FF)    // Top gradient background
val SkySurfaceBottom = Color(0xFFE5F3FE) // Bottom gradient background
val SkyCardBorder = Color(0xFFCDE8FC)    // Subtle sky-tinted card border

// Neutral & Text Colors (High legibility for seniors)
val PureWhite = Color(0xFFFFFFFF)
val DeepOcean = Color(0xFF0C2D48)        // Primary text color
val SlateBlue = Color(0xFF476A86)        // Secondary text color
val SoftDivider = Color(0xFFE2EFFA)

// Semantic Accents
val MintSuccess = Color(0xFF0D9488)      // Goal achieved teal-mint
val MintContainer = Color(0xFFCCFBF1)    // Goal achieved soft container
val CoralWarm = Color(0xFFE11D48)        // Delete / urgent warning
val CoralBlush = Color(0xFFFF8FAB)       // Cute mascot rosy cheeks
val AmberSoft = Color(0xFFD97706)        // Permission / alert notice
val AmberContainer = Color(0xFFFEF3C7)

// Dark Theme Palette (Calm night sky)
val NightSkyBg = Color(0xFF091926)
val NightSkySurface = Color(0xFF102536)
val NightSkyContainer = Color(0xFF16354D)
val NightSkyPrimary = Color(0xFF38BDF8)
val NightSkyOnPrimary = Color(0xFF052033)
val NightSkyText = Color(0xFFEBF6FF)
val NightSkyMuted = Color(0xFF9EC2DE)
