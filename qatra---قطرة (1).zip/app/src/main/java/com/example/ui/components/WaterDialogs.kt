package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.util.ArabicFormatters
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CupSizeDialog(
    currentCupSizeMl: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val presets = listOf(150, 200, 250, 330, 500)
    var selectedMl by remember { mutableIntStateOf(currentCupSizeMl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Text(
                text = "تحديد حجم الكوب",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "اختر سعة الكوب المعتاد لوالدك:",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "$selectedMl مل",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { size ->
                        FilterChip(
                            selected = selectedMl == size,
                            onClick = { selectedMl = size },
                            label = {
                                Text(
                                    text = "$size مل",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("cup_preset_$size")
                        )
                    }
                }

                Slider(
                    value = selectedMl.toFloat(),
                    onValueChange = { raw ->
                        selectedMl = ((raw / 25f).roundToInt() * 25).coerceIn(100, 750)
                    },
                    valueRange = 100f..750f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedMl) },
                modifier = Modifier.testTag("confirm_cup_size_button")
            ) {
                Text("حفظ", style = MaterialTheme.typography.labelLarge)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DailyGoalDialog(
    currentGoalMl: Int,
    cupSizeMl: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val presets = listOf(1500, 2000, 2500, 3000)
    var sliderValue by remember { mutableFloatStateOf(currentGoalMl.toFloat()) }
    val selectedGoal = ((sliderValue / 100f).roundToInt() * 100).coerceIn(1000, 4000)
    val approxCups = (selectedGoal.toFloat() / cupSizeMl.coerceAtLeast(50)).roundToInt()

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Text(
                text = "تحديد الهدف اليومي",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "${ArabicFormatters.formatLitersOrMl(selectedGoal)} ($selectedGoal مل)",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "يساوي تقريباً $approxCups أكواب بحجم $cupSizeMl مل",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { goal ->
                        FilterChip(
                            selected = selectedGoal == goal,
                            onClick = { sliderValue = goal.toFloat() },
                            label = {
                                Text(
                                    text = ArabicFormatters.formatLitersOrMl(goal),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("goal_preset_$goal")
                        )
                    }
                }

                Slider(
                    value = sliderValue,
                    onValueChange = { sliderValue = it },
                    valueRange = 1000f..4000f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedGoal) },
                modifier = Modifier.testTag("confirm_goal_button")
            ) {
                Text("حفظ الهدف", style = MaterialTheme.typography.labelLarge)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ReminderTimeDialog(
    initialHour: Int,
    initialMinute: Int,
    initialLabel: String,
    isEditing: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (hour: Int, minute: Int, label: String) -> Unit
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = false
    )
    var label by remember { mutableStateOf(initialLabel) }
    val quickLabels = listOf("الصباح", "الظهيرة", "العصر", "المساء", "قبل النوم")

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Text(
                text = if (isEditing) "تعديل موعد التذكير" else "إضافة موعد تذكير جديد",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TimePicker(state = timePickerState)

                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("عنوان التذكير (اختياري)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reminder_label_input")
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickLabels.forEach { preset ->
                        FilterChip(
                            selected = label == preset,
                            onClick = { label = preset },
                            label = { Text(preset, style = MaterialTheme.typography.labelMedium) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(timePickerState.hour, timePickerState.minute, label)
                },
                modifier = Modifier.testTag("confirm_reminder_button")
            ) {
                Text("حفظ الموعد", style = MaterialTheme.typography.labelLarge)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}

@Composable
fun GoalCelebrationDialog(
    dailyGoalMl: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Text(
                text = "ما شاء الله! أحسنت",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.tertiary
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "تم الوصول إلى هدف اليوم (${ArabicFormatters.formatLitersOrMl(dailyGoalMl)}) بنجاح. حافظ على هذا النشاط لصحتك وعافيتك!",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_celebration_button")
            ) {
                Text("الحمد لله", style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}
