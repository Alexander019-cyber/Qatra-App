package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.ArabicFormatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Qatra`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Qatra - قطرة", appName)
    }

    @Test
    fun `arabic time formatting works for morning and evening`() {
        assertEquals("09:00 صباحاً", ArabicFormatters.formatTime12hArabic(9, 0))
        assertEquals("03:30 مساءً", ArabicFormatters.formatTime12hArabic(15, 30))
        assertEquals("12:00 مساءً", ArabicFormatters.formatTime12hArabic(12, 0))
        assertEquals("12:05 صباحاً", ArabicFormatters.formatTime12hArabic(0, 5))
    }

    @Test
    fun `last 7 days returns 7 chronological date keys ending today`() {
        val keys = ArabicFormatters.lastNDaysKeys(7)
        assertEquals(7, keys.size)
        assertEquals(ArabicFormatters.todayDateKey(), keys.last())
        assertTrue(keys.zipWithNext().all { (a, b) -> a < b })
    }
}
